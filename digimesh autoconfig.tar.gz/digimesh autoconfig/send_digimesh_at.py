#!/usr/bin/python3

"""
Module contains tools allowing communicating and configuring DigiMesh module using AT commands.
"""

import os
import subprocess
import argparse
import sys
import time
from contextlib import suppress
from datetime import datetime
from datetime import datetime as dt
from enum import Enum
from typing import List
from typing import Optional
from serial.tools import list_ports

import serial


class DigiMesh:
    """
    Class contains tools for communication with DigiMesh module.
    """
    # Delay before reading each response, seconds.
    minimum_response_delay_s = 0.1

    def __init__(self, serial_port: str, baud_rate: int, verbose: int = 1, log: str = None) -> None:
        """
        Modem class initialisation.

        Parameters
        ----------
        serial_port: str
            Name of port where modem is connected.
        baud_rate: int
            Serial port speed.
        verbose: int
            Verbose level - 0 -> no messages.
        log: str
            Log filepath. Does not log information if not specified.
        """
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.ser = serial.Serial(self.serial_port, self.baud_rate, timeout=0.01)
        self._termination_delay = 1 / self.baud_rate * 1000

        self.verbose = verbose
        self.log = log

    def __del__(self) -> None:
        """
        Close serial port before object destruction.
        """
        self.close()

    def close(self) -> None:
        """
        Close modem connection.
        """
        with suppress(Exception):
            self.ser.close()

    def flush_input_buffer(self) -> None:
        """
        Read all data from input buffer without saving.
        """
        start_time = datetime.now()
        while (datetime.now() - start_time).seconds < 2:
            data = self.ser.readline()
            if not data:
                break

    def save_and_print_log(self, log: str) -> None:
        if self.verbose >= 2:
            print(log)
        if not self.log:
            return
        file_open_mode = 'w' if not os.path.isfile(self.log) else 'a'
        with open(self.log, file_open_mode) as f:
            time_str = dt.now().strftime("%d_%m_%Y %H:%M:%S")
            f.write(f"T->{time_str}\n")
            f.write(log)

    def send_at_command(
        self,
        command,
        get_response: bool = True,
        response_timeout_s: float = 3,
        eol: str = "\r\n"
    ) -> str:
        """
        Send AT command to DigiMesh and read response.

        Parameters
        ----------
        command: str
            AT command.
        get_response: bool, default=True
            If False - No wait for response. Just send a command.
        response_timeout_s:
            Timeout for getting response from modem in seconds.
        eol: str, default="\r\n"
            Symbol ending the line.

        Returns
        -------
        str
            Response.
        """
        response = ""
        self.flush_input_buffer()
        self.ser.write((command + eol).encode())  # Send the AT command

        if get_response:
            time.sleep(self.minimum_response_delay_s)
            response = self.read_at_response(response_timeout_s)
        self.save_and_print_log(f">> {command}\n<< {response}\n\n")
        return response

    def read_at_response(self, response_timeout_s: float = 3) -> str:
        """
        Read response from DigiMesh.

        Parameters
        ----------
        response_timeout_s: float
            Timeout for getting response from modem in seconds.

        Returns
        -------
        str
            Response.
        """
        response = ""
        empty_msg_counter = 0
        start_time = datetime.now()
        while (datetime.now() - start_time).total_seconds() < response_timeout_s:
            response_bytes = self.ser.readline()
            response_decoded = ""
            with suppress(Exception):
                response_decoded = response_bytes.decode().strip()
            if response_decoded and len(response_decoded) > 0:
                response += response_decoded + "\n"
                empty_msg_counter = 0
                continue
            if response:
                if empty_msg_counter == 3:
                    break
                empty_msg_counter += 1
            time.sleep(self._termination_delay)
        return response.strip()

    def setup(self) -> bool:
        """
        Setup modem parameters.

        Returns
        -------
        bool
            False if setup failed else True
        """
        response = self.send_at_command("+++", eol="", response_timeout_s=1)
        if response != "OK":
            return False
        response = self.send_at_command("ATAP1")
        if response != "OK":
            return False
        response = self.send_at_command("ATAP")
        if response != "1":
            return False
        return True

    @classmethod
    def scan_serial_ports(cls, s_ports: list = None, baud_rates: list = None) -> Optional["DigiMesh"]:
        """
        Scan all serial ports and return DigiMesh object if found.

        Returns
        -------
        DigiMesh | None
            Discovered device.
        """
        if s_ports and baud_rates:
            for s_port in s_ports:
                for baud_rate in baud_rates:
                    device = cls(s_port, baud_rate)
                    setup_result = device.setup()
                    if setup_result:
                        return device
            return
        s_ports = [port.device for port in list(list_ports.comports()) if port.device.find("ttyUSB") >= 0]
        primary_baud_rates = [9600, 115200]
        secondary_baud_rates = [4800, 19200, 38400, 57600, 230400]
        device = DigiMesh.scan_serial_ports(s_ports, primary_baud_rates)
        return device if device else DigiMesh.scan_serial_ports(s_ports, secondary_baud_rates)


def parse_parameters():
    """
    Parse command line parameters.
    """
    # Check if at least one parameter is provided
    parser = argparse.ArgumentParser(description="DigiMesh AT Tool")
    parser.add_argument(
        "-s",
        type=str,
        help="Serial port name."
    )
    parser.add_argument(
        "-b",
        type=int,
        help="Baud rate."
    )
    parser.add_argument(
        "--scan",
        action='store_true',
        help="Scan all serial ports and baud rates automatically to find tne DigiMesh module."
    )
    return parser.parse_known_args()


if __name__ == "__main__":
    at_command = ""
    args, positionals = parse_parameters()
    if positionals:
        at_command = positionals[0]
    digi_mesh = None
    if (args.scan and at_command) or (not args.s and not args.b and not at_command):
        digi_mesh = DigiMesh.scan_serial_ports()
        if digi_mesh:
            print(f"DigiMesh discovered. Port: {digi_mesh.serial_port} Baud: {digi_mesh.baud_rate}")
    elif not args.s:
        print("Please provide serial port.")
    elif not args.b:
        print("Please provide baud rate.")
    else:
        digi_mesh = DigiMesh(serial_port=args.s, baud_rate=args.b)
        setup_result = digi_mesh.setup()
        if not setup_result:
            print(f"Error during initialization DigiMesh on port {args.s} with baud rate {args.b}.")

    if digi_mesh and at_command:
        result = digi_mesh.send_at_command(at_command, response_timeout_s=5)
        print(result)
