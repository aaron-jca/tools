
import subprocess
import re

"""
Small script to configure DigiMesh module. This script will set the module to the correct mode, 
set the baud rate to 115200 and check if the configuration was successful.
If this script fails, try running the send_digimesh_at.py script manually with `python3 send_digimesh_at.py --scan`
then run again
"""
class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    MAGENTA = '\033[35m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

if __name__ == "__main__":
    print(f"{bcolors.HEADER}Configuring DigiMesh module.{bcolors.ENDC}\n")

    print("Scanning for digimesh module and setting mode with ATAP1...")
    result = subprocess.run(['python3', 'send_digimesh_at.py', "ATAP1", "--scan"], stdout=subprocess.PIPE)
    string_result = result.stdout.decode('utf-8')

    port = re.search(r'Port:\s*(\S+)', string_result)
    if port:
        print(f"{bcolors.OKCYAN}Found digimesh on port {bcolors.OKGREEN}" + port.group(1) + f"{bcolors.ENDC}")
    else:
        print(f" {bcolors.FAIL}No digimesh found.")
        exit(1)
    at_result = string_result.split("\n")[1]
    print("ATAP1 result: " + at_result + "\n")
    if(at_result != "OK"):
        print(f"{bcolors.FAIL}Failed to set digimesh mode.")
        exit(1)

    print("Checking command mode...")
    result = subprocess.run(['python3', 'send_digimesh_at.py', "ATAP", "-s", port.group(1), "-b", str(9600)], stdout=subprocess.PIPE)
    string_result = result.stdout.decode('utf-8')

    print("ATAP result: " + string_result)
    if(string_result.strip() != "1"):
        print(f"{bcolors.FAIL}Failed to set command mode.")
        exit(1)

    print(f"{bcolors.OKCYAN}Setting baud rate to 115200...{bcolors.ENDC}")
    result = subprocess.run(['python3', 'send_digimesh_at.py', "AT BD 7 WR", "-s", port.group(1), "-b", str(9600)], stdout=subprocess.PIPE)
    string_result = result.stdout.decode('utf-8')
    print("AT BD 7 WR result: " + string_result)
    if(string_result.strip() != "OK"):
        print(f"{bcolors.FAIL}Failed to set baud rate.")
        exit(1)

    print(f"{bcolors.OKCYAN}Checking baudrate with AT BD...{bcolors.ENDC}")
    result = subprocess.run(['python3', 'send_digimesh_at.py', "AT BD", "--scan"], stdout=subprocess.PIPE)
    string_result = result.stdout.decode('utf-8')
    print("AT BD result " + string_result.split('\n')[1])
    if("7" not in string_result):
        print(f"{bcolors.FAIL}Failed to set baud rate.")
        exit(1)
        
    print(f"{bcolors.OKGREEN}Configuring DigiMesh module done.{bcolors.ENDC}")

    print("Getting Digimesh MAC address:")
    result = subprocess.run(['python3', 'send_digimesh_at.py', "AT SH", "--scan"], stdout=subprocess.PIPE)
    sh_result = result.stdout.decode('utf-8').split('\n')[1]
    result = subprocess.run(['python3', 'send_digimesh_at.py', "AT SL", "--scan"], stdout=subprocess.PIPE)
    sl_result = result.stdout.decode('utf-8').split('\n')[1]
    mac_address = sh_result.strip() + sl_result.strip()
    print(f"{bcolors.UNDERLINE}{bcolors.MAGENTA}Digimesh MAC: {bcolors.BOLD}{bcolors.OKCYAN}[0x" + 
          mac_address + f"]{bcolors.ENDC}")
